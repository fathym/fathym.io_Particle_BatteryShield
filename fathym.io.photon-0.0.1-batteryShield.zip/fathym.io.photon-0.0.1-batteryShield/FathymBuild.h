// Tells the library that the current project is building via local Particle Dev
#define LOCAL_BUILD true

//==== Device Configuration =====================================================================

  // The flash memory offset where Fathym device configuration settings are written to/read from
  #define FATHYM_CONFIG_ADDRESS 0

  // The size of the character buffer used to serialize/deserialize the configuration JSON
  #define FATHYM_CONFIG_BUFFER_SIZE 512

  // The brightness of connected LEDs (0-255)
  #define FATHYM_LED_BRIGHTNESS 255

//==== End Device Configuration =================================================================


//==== Device Data & Publishing ==========================================================

  // The name of the device ID property to use
  #define FATHYM_ID_PROPERTY "id"

  // Whether or not to include the device's name
  #define FATHYM_ADD_DEVICE_NAME true

  // The name of the device name property to use
  #define FATHYM_DEVICE_NAME_PROPERTY "name"

  // The default number of decimal places to include from numbers with decimal values
  #define FATHYM_DEFAULT_DECIMAL_PLACES 6

  // The interval in minutes that the device will resynchronize device time to Particle cloud time
  #define FATHYM_RESYNC_TIME_MINS 1440 // resync every 24 hours

  // Whether or not to include the current uptime of the device
  #define FATHYM_ADD_UPTIME true

  // The name of the device uptime property to use
  #define FATHYM_UPTIME_PROPERTY "ut"

  // Whether or not to include a time stamp on each published message
  #define FATHYM_ADD_TIMESTAMP true

  // The time zone offset to use when adding a time stamp to the published message
  #define FATHYM_TIMEZONE_OFFSET -7 // Colorado/Mountain time!

  // The name of the time stamp property to use
  #define FATHYM_TIMESTAMP_PROPERTY "ts"

  // Whether or not to include the device's free memory in the message for detecting memory leaks
  #define FATHYM_ADD_FREE_MEMORY true

  // The name of the free memory property to use
  #define FATHYM_FREE_MEMORY_PROPERTY "mem"

  // Whether or not the Fathym library will automatically handle publishing data or not
  #define FATHYM_AUTO_PUBLISH true

  // The publish rate (in seconds) for message data (applies when FATHYM_AUTO_PUBLISH is set to true)
  #define FATHYM_PUBLISH_RATE 10

//==== End Device Data & Publishing =============================================================

//==== Communications & Network =================================================================

  // The protocol to use to publish messages ("MQTT" or "HTTP")
  #define PUBLISH_PROTOCOL "MQTT"

  // The server/host/domain name of the HTTP API endpoint to publish to
  #define HTTP_HOST "target.host.com"

  // The relative path api/URL portion of the HTTP API endpoint to publish to
  #define HTTP_URL "/api/v1/your/endpoint"

  // The port of the HTTP endpoint to publish to
  #define HTTP_PORT 80

  // Custom headers separated by new line charater's that are used durring HTTP posts;
  // Uncomment to use.
  //#define HTTP_HEADERS "Header-Values: Separated by new lines\nContent-Type: application/json\n";

  // The buffer size used to read in the response to HTTP POST calls
  #define HTTP_RESPONSE_MAX_SIZE 512

  // MQTT server to connect to for messagr queuing and receiving messages
  #define MQTT_SERVER "hyena.rmq.cloudamqp.com"

  // The MQTT credentials username to connect as
  #define MQTT_USERNAME "imjxeygk:imjxeygk"

  // The MQTT credentials username to connect as
  #define MQTT_PASSWORD "U4D-ogZ3vIyDb_4FWg2NQmSU-qj1mSU3"

  // The group ID that the device will use for communications with Fathym
  #define MQTT_MESSAGE_GROUP "public"

  // Default to standard MQTT port
  #define MQTT_PORT 1883

  // The number of seconds to use for the MQTT connection keep alive.
  // The keep alive needs to be longer than your publish rate otherwise
  // the connection will continuously time out/reconnect after one publish.
  #define MQTT_KEEPALIVE 90

  // The maximum size of the MQTT header in bytes
  #define MQTT_MAX_HEADER_SIZE 160

  // The reserved buffer size in bytes for MQTT data packet buffer.
  // The maximum buffer size available to serialize JSON messages to string
  // is determined by the MQTT_MAX_PACKET_SIZE - MQTT_MAX_HEADER_SIZE.
  #define MQTT_MAX_PACKET_SIZE 1024

  // The rate at which the MQTT communication loop updates in milliseconds.
  // This includes ping/keep alive/QoS/receiving messages. It runs on a
  // software timer independent of the main program loop.
  #define MQTT_UPDATE_RATE 250

  // The number of times to run the MQTT communications update loop per
  // iteration as defined by MQTT_UPDATE_RATE. The update loop will consume
  // 1 waiting message per update per update cycle.
  #define MQTT_MESSAGES_PER_UPDATE 4

  // Whether or not to include the current WIFI signal strength
  #define FATHYM_ADD_RSSI true

  // The name of the WIFI signal strength/RSSI property to use
  #define FATHYM_RSSI_PROPERTY "rssi"

//==== End Communications & Networking ==========================================================

//==== Debugging ================================================================================

  // Whether or not to use LED(s) to visualize various status indicators around various Fathym events
  #define FATHYM_LED_STATUS true

  // The LED pin to use when showing status
  #define FATHYM_STATUS_LED_PIN D7

  // The LED pin to use when showing successful publish events
  #define FATHYM_PUBLISH_LED_PIN D7

  // The number of milliseconds to flash the debug LED to indicate a successful publish
  #define FATHYM_SINGLE_LED_DELAY 20

  // The number of milliseconds to flash the debug LED to indicate a successful publish
  #define FATHYM_RGB_LED_DELAY 150

//==== End Debugging ============================================================================

//==== Battery Shield (optional) ================================================================
/* This section is optional if you're creating a battery powered design that uses the SparkFun
 * Photon Battery Shield (https://www.sparkfun.com/products/13626). Uncomment all of the
 * #define lines below to use the battery shield with the Fathym library
 */

  #define FATHYM_USE_BATTERY_POWER true

  // Whether or not to report on battery voltage and charge level
  #define FATHYM_MONITOR_BATTERY true

  // If monitoring battery power, whether or not to include the voltage level
  #define FATHYM_ADD_BATTERY_VOLTAGE true

  // The name of the battery voltage memory property to use
  #define FATHYM_BATTERY_VOLTAGE_PROPERTY "batV"

  // If monitoring battery power, whether or not to include the charge level
  #define FATHYM_ADD_BATTERY_CHARGE true

  // The name of the battery voltage memory property to use
  #define FATHYM_BATTERY_CHARGE_PROPERTY "batC"

//==== End Battery Shield =======================================================================
